import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';

void main() {
  runApp(const WatchServiceApp());
}

class WatchServiceApp extends StatelessWidget {
  const WatchServiceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Watch Service Center',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: const WatchIntakeScreen(),
    );
  }
}

class WatchIntakeScreen extends StatefulWidget {
  const WatchIntakeScreen({super.key});

  @override
  State<WatchIntakeScreen> createState() => _WatchIntakeScreenState();
}

class _WatchIntakeScreenState extends State<WatchIntakeScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _watchDetailsController = TextEditingController();
  final TextEditingController _workController = TextEditingController();
  
  File? _watchImage;
  final ImagePicker _picker = ImagePicker();

  Future<void> _takePhoto() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      setState(() {
        _watchImage = File(pickedFile.path);
      });
    }
  }

  void _submitAndShare() {
    if (_formKey.currentState!.validate() && _watchImage != null) {
      String customerName = _nameController.text;
      String customerPhone = _phoneController.text;
      String watchInfo = _watchDetailsController.text;
      String workNeeded = _workController.text;

      String message = "⏱️ *SERVICE CENTER JOB SHEET* ⏱️\n\n"
          "*Customer:* $customerName\n"
          "*Phone:* $customerPhone\n"
          "*Watch Details:* $watchInfo\n"
          "*Work Required:* $workNeeded\n\n"
          "Thank you for servicing with us!";

      Share.shareXFiles(
        [XFile(_watchImage!.path)],
        text: message,
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all fields and capture a photo of the watch.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Watch Service Intake'),
        backgroundColor: Colors.blueGrey,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(labelText: 'Customer Name'),
                validator: (value) => value!.isEmpty ? 'Enter customer name' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _phoneController,
                decoration: const InputDecoration(labelText: 'Phone Number (with Country Code)'),
                keyboardType: TextInputType.phone,
                validator: (value) => value!.isEmpty ? 'Enter phone number' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _watchDetailsController,
                decoration: const InputDecoration(labelText: 'Watch Brand / Model / Serial'),
                validator: (value) => value!.isEmpty ? 'Enter watch details' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _workController,
                decoration: const InputDecoration(labelText: 'Work Needed (e.g., Battery, Glass, Overhaul)'),
                maxLines: 3,
                validator: (value) => value!.isEmpty ? 'Enter work needed' : null,
              ),
              const SizedBox(height: 24),
              _watchImage == null
                  ? ElevatedButton.icon(
                      onPressed: _takePhoto,
                      icon: const Icon(Icons.camera_alt),
                      label: const Text('Take Watch Photo'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                    )
                  : Column(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.file(_watchImage!, height: 200, fit: BoxFit.cover),
                        ),
                        TextButton.icon(
                          onPressed: _takePhoto,
                          icon: const Icon(Icons.refresh),
                          label: const Text('Retake Photo'),
                        ),
                      ],
                    ),
              const SizedBox(height: 30),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                onPressed: _submitAndShare,
                child: const Text(
                  'Save & Send via WhatsApp',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
