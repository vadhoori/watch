# Watch Service Center App

A mobile application built with Flutter for Android and iOS that streamlines watch service intake, captures photos of watches, and shares job details & photos directly via WhatsApp to customers and your internal shop group.

## How to Build the APK (Android)

1. Ensure you have [Flutter SDK](https://docs.flutter.dev/get-started/install) installed on your computer.
2. Open your terminal in this project folder.
3. Run the following commands:
   ```bash
   flutter pub get
   flutter build apk --release
   ```
4. The generated APK will be located at:
   `build/app/outputs/flutter-apk/app-release.apk`
5. Transfer the APK to your Android phone and install it!
